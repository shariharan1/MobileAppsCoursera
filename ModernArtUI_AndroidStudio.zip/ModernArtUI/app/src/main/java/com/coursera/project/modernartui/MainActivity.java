package com.coursera.project.modernartui;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.util.Log;

public class MainActivity extends ActionBarActivity {

    static private final String TAG = "Modern Art UI";

    private int boxR1C1Start = 16776960;
    private int boxR2C1Start = 255;
    private int boxR1C2Start = 16711680;
    private int boxR3C2Start = 65280;

    private TextView boxR3C2 =  null;
    private TextView boxR1C1 =  null;
    private TextView boxR2C1 =  null;
    private TextView boxR1C2 =  null;

    private DialogFragment mDialog;
    static private final String URL = "http://www.moma.org";
    static private final String CHOOSER_TEXT = "Load " + URL + " with:";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Log.i(TAG,"Entered onCreate()");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        boxR1C1 =  (TextView)findViewById(R.id.boxR1C1);
        boxR2C1 =  (TextView)findViewById(R.id.boxR2C1);
        boxR1C2 =  (TextView)findViewById(R.id.boxR1C2);
        boxR3C2 =  (TextView)findViewById(R.id.boxR3C2);

        boxR1C1Start = getBoxColor(boxR1C1);
        boxR2C1Start = getBoxColor(boxR2C1);
        boxR1C2Start = getBoxColor(boxR1C2);
        boxR3C2Start = getBoxColor(boxR3C2);

        Log.i(TAG," boxR1C1Start Color > " + boxR1C1Start);
        Log.i(TAG," boxR2C1Start Color > " + boxR2C1Start);
        Log.i(TAG," boxR1C2Start Color > " + boxR1C2Start);
        Log.i(TAG," boxR3C2Start Color > " + boxR3C2Start);

//        boxR1C1.setBackgroundColor(boxR1C1Start);
//        boxR2C1.setBackgroundColor(boxR2C1Start);
//        boxR1C2.setBackgroundColor(boxR1C2Start);
//        boxR3C2.setBackgroundColor(boxR3C2Start);

        // setup the seekbar object/listener
        SeekBar seekBar = (SeekBar)findViewById(R.id.seekBar);
        seekBar.setMax(255);
        seekBar.setOnSeekBarChangeListener( new SeekBar.OnSeekBarChangeListener() {

            int lastValue = 0;

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                Log.i(TAG,"Entered onProgressChanged()");

                // change progress text label with current seekbar value
                //textProgress.setText("The value is: "+progress);
                // change action text label to changing
                //textAction.setText("changing");
                changeColors(progress);

                lastValue = progress;
                Log.i(TAG,"Exited onProgressChanged()");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // do nothing!
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // do nothing!
            }

            private void changeColors(int progress)
            {
                Log.i(TAG,"Entered changeColors()");

                //int newColor = boxR1C1Start + (progress*100);
                int newColor = boxR1C1Start + progress;
                boxR1C1.setBackgroundColor(newColor);
                Log.i(TAG," boxR1C1 Current Color > " + newColor);

                //newColor = boxR2C1Start - (progress*1000);
                newColor = boxR2C1Start + progress;
                Log.i(TAG," boxR2C1 Current Color > " + newColor);
                boxR2C1.setBackgroundColor(newColor);

                newColor = boxR1C2Start + progress;
                Log.i(TAG," boxR1C2 Current Color > " + newColor);
                boxR1C2.setBackgroundColor(newColor);

                newColor = boxR3C2Start + progress;
                Log.i(TAG," boxR3C2 Current Color > " + newColor);
                boxR3C2.setBackgroundColor(newColor);

                Log.i(TAG,"Exited changeColors()");
            }

        }
        );

        Log.i(TAG,"Exited onCreate()");
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        // Create a new AlertDialogFragment
        mDialog = new AlertDialogFragment();

        // Show AlertDialogFragment
        mDialog.show(getFragmentManager(), "Alert");

        return super.onOptionsItemSelected(item);
    }

    private void changeBoxColor(TextView box, int newColor)
    {
        int color = 0;
        Drawable background = box.getBackground();
        if (background instanceof ColorDrawable) {
            color = ((ColorDrawable) background).getColor();
        }
        //color = progress;
        box.setBackgroundColor(newColor);
        box.setText(color+"");

    }

    private int getBoxColor(TextView box)
    {
        int color = 0;
        Drawable background = box.getBackground();
        if (background instanceof ColorDrawable) {
            color = ((ColorDrawable) background).getColor();
        }

        return color;

    }

    // Class that creates the AlertDialog
    public class AlertDialogFragment extends DialogFragment {


        public AlertDialogFragment newInstance() {
            return new AlertDialogFragment();
        }

        // Build AlertDialog using AlertDialog.Builder
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {

            //LayoutInflater inflater = getLayoutInflater();
            //View dialoglayout = inflater.inflate(R.layout.dialog_layout, null);

            return new AlertDialog.Builder(getActivity())
                //.setView(dialoglayout)
                .setMessage(R.string.more_info_text)

                // User cannot dismiss dialog by hitting back button
                .setCancelable(false)
                        // Set up No Button
                .setNegativeButton("Visit MOMA",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int id) {
                                ((MainActivity) getActivity())
                                        .handleMoreInfo(true);
                            }
                        })

                        // Set up Yes Button
                .setPositiveButton("Not Now",
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    final DialogInterface dialog, int id) {
                                ((MainActivity) getActivity())
                                        .handleMoreInfo(false);
                            }
                        }).create();
        }
    }

    // Open Browser or dismiss dialog!
    private void handleMoreInfo(boolean visitMoma) {
        if (visitMoma) {

            Log.i(TAG, "Visit MOMA please ... !");

            //Intent baseIntent = null;
            Intent baseIntent = new Intent (Intent.ACTION_VIEW, Uri.parse(URL));

            // T ODO - Create a chooser intent, for choosing which Activity
            // will carry out the baseIntent
            // (HINT: Use the Intent class' createChooser() method)
            Intent chooserIntent = Intent.createChooser(baseIntent, CHOOSER_TEXT);

            Log.i(TAG,"Chooser Intent Action:" + chooserIntent.getAction());

            startActivity(chooserIntent);


        } else {

            // Abort ShutDown and dismiss dialog
            mDialog.dismiss();
        }
    }



}
